package synchronization;

public class Explicit {
	
	

}
